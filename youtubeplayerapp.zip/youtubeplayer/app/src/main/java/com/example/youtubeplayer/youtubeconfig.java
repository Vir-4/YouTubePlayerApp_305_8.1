package com.example.youtubeplayer;

public class youtubeconfig
{

    public  youtubeconfig()
    {

    }

    private static final String API_KEY = "AIzaSyCTxfXsYJG3Aq6WqONBHSONEDo-nys98pk";

    public static String getApiKey() {
        return API_KEY;
    }
}
